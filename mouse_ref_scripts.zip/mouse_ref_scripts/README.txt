you need to add 2 mouse genome references: 
1st into: "/Users/$USER/MMBSearch/exp_environment/Mus_musculus.GRCm39.dna.primary_assembly/Mus_musculus.GRCm39.dna.primary_assembly.fa"
2nd into: "mouse_mmbir_ref/mouse_mmbir_ref.fa" (within exp_environment folder)